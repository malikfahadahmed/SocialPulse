import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, BarChart2, FileSearch, Laptop, MapPin, Search, Trophy } from "lucide-react"
import { Logo } from "@/components/logo"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between py-4">
          <Logo />
          <nav className="flex items-center gap-4">
            <Button asChild variant="ghost" size="sm">
              <Link href="/about">About</Link>
            </Button>
            <Button asChild size="sm">
              <Link href="/quizzes">Start SEO Audit</Link>
            </Button>
          </nav>
        </div>
      </header>

      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20 -z-10" />
        <div className="container relative">
          <div className="grid gap-10 lg:grid-cols-2 lg:gap-20 items-center">
            <div className="flex flex-col gap-6">
              <div className="inline-flex items-center rounded-full border px-4 py-1.5 text-sm font-medium">
                <span className="flex h-2 w-2 rounded-full bg-green-500 mr-2"></span>
                Test your SEO knowledge
              </div>
              <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl">
                Boost Your SEO Skills with Interactive Quizzes
              </h1>
              <p className="text-lg text-muted-foreground md:text-xl">
                Take our comprehensive SEO quizzes, get personalized recommendations, and share your results with your
                network.
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <Button asChild size="lg" className="px-8">
                  <Link href="/quizzes">
                    Start Quiz Now
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="/about">Learn More</Link>
                </Button>
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Trophy className="h-4 w-4" />
                  <span>6 Quiz Categories</span>
                </div>
                <div className="flex items-center gap-1">
                  <FileSearch className="h-4 w-4" />
                  <span>60+ Questions</span>
                </div>
                <div className="flex items-center gap-1">
                  <BarChart2 className="h-4 w-4" />
                  <span>Detailed Analysis</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl blur-xl opacity-20 -z-10"></div>
              <div className="relative bg-white dark:bg-gray-950 rounded-xl border shadow-lg overflow-hidden">
                <div className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-xl font-semibold">On-Page SEO Quiz</h3>
                    <span className="text-sm text-muted-foreground">Question 3 of 10</span>
                  </div>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <h4 className="font-medium">What is the recommended format for image alt text?</h4>
                      <p className="text-sm text-muted-foreground">
                        Select the best practice for optimizing image alt text.
                      </p>
                    </div>
                    <div className="space-y-3">
                      <div className="flex items-start space-x-2 border rounded-md p-3 hover:bg-muted/50 transition-colors">
                        <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-primary">
                          <div className="h-2.5 w-2.5 rounded-full bg-primary"></div>
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">Brief description with relevant keywords</p>
                          <p className="text-sm text-muted-foreground mt-1">Descriptive and includes context</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-2 border rounded-md p-3 hover:bg-muted/50 transition-colors">
                        <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full border"></div>
                        <div className="flex-1">
                          <p className="font-medium">Keyword stuffing</p>
                          <p className="text-sm text-muted-foreground mt-1">This practice can be seen as spam</p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-2 border rounded-md p-3 hover:bg-muted/50 transition-colors">
                        <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full border"></div>
                        <div className="flex-1">
                          <p className="font-medium">Just the filename</p>
                          <p className="text-sm text-muted-foreground mt-1">Not descriptive or helpful for SEO</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <Button variant="outline">Previous</Button>
                      <Button>Next</Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
            Explore Our SEO Quiz Categories
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Test your knowledge across all aspects of search engine optimization
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <Card className="flex flex-col items-center justify-between p-2 transition-all hover:shadow-md">
            <CardHeader className="items-center text-center">
              <div className="rounded-full bg-blue-100 dark:bg-blue-900 p-3 mb-2">
                <Search className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <CardTitle>On-Page SEO</CardTitle>
              <CardDescription>Test your knowledge of on-page optimization factors</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-sm text-muted-foreground">10 questions about meta tags, content structure, and more</p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" size="sm">
                <Link href="/quizzes/on-page">Take Quiz</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card className="flex flex-col items-center justify-between p-2 transition-all hover:shadow-md">
            <CardHeader className="items-center text-center">
              <div className="rounded-full bg-purple-100 dark:bg-purple-900 p-3 mb-2">
                <FileSearch className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <CardTitle>Technical SEO</CardTitle>
              <CardDescription>Evaluate your technical optimization knowledge</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-sm text-muted-foreground">10 questions about site speed, indexing, and crawlability</p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" size="sm">
                <Link href="/quizzes/technical">Take Quiz</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card className="flex flex-col items-center justify-between p-2 transition-all hover:shadow-md">
            <CardHeader className="items-center text-center">
              <div className="rounded-full bg-green-100 dark:bg-green-900 p-3 mb-2">
                <BarChart2 className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <CardTitle>Keyword Strategy</CardTitle>
              <CardDescription>Test your keyword research and implementation skills</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-sm text-muted-foreground">
                10 questions about keyword selection, intent, and placement
              </p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" size="sm">
                <Link href="/quizzes/keywords">Take Quiz</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card className="flex flex-col items-center justify-between p-2 transition-all hover:shadow-md">
            <CardHeader className="items-center text-center">
              <div className="rounded-full bg-amber-100 dark:bg-amber-900 p-3 mb-2">
                <Laptop className="h-6 w-6 text-amber-600 dark:text-amber-400" />
              </div>
              <CardTitle>Mobile Optimization</CardTitle>
              <CardDescription>Assess your mobile SEO knowledge</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-sm text-muted-foreground">
                10 questions about responsive design, mobile-first indexing, and more
              </p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" size="sm">
                <Link href="/quizzes/mobile">Take Quiz</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card className="flex flex-col items-center justify-between p-2 transition-all hover:shadow-md">
            <CardHeader className="items-center text-center">
              <div className="rounded-full bg-red-100 dark:bg-red-900 p-3 mb-2">
                <MapPin className="h-6 w-6 text-red-600 dark:text-red-400" />
              </div>
              <CardTitle>Local SEO</CardTitle>
              <CardDescription>Test your local search optimization knowledge</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-sm text-muted-foreground">
                10 questions about Google Business Profile, local citations, and more
              </p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" size="sm">
                <Link href="/quizzes/local">Take Quiz</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card className="flex flex-col items-center justify-between p-2 transition-all hover:shadow-md">
            <CardHeader className="items-center text-center">
              <div className="rounded-full bg-indigo-100 dark:bg-indigo-900 p-3 mb-2">
                <FileSearch className="h-6 w-6 text-indigo-600 dark:text-indigo-400" />
              </div>
              <CardTitle>Content Quality</CardTitle>
              <CardDescription>Evaluate your content optimization knowledge</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-sm text-muted-foreground">
                10 questions about E-A-T, content structure, and engagement
              </p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" size="sm">
                <Link href="/quizzes/content">Take Quiz</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </section>

      <section className="bg-slate-50 dark:bg-slate-900 py-20">
        <div className="container">
          <div className="grid gap-10 lg:grid-cols-2 items-center">
            <div className="flex flex-col gap-6">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Share Your SEO Knowledge</h2>
              <p className="text-lg text-muted-foreground">
                After completing a quiz, share your results on social media and challenge your colleagues to beat your
                score.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <div className="rounded-full bg-green-100 dark:bg-green-900 p-1 mt-0.5">
                    <svg
                      className="h-4 w-4 text-green-600 dark:text-green-400"
                      fill="none"
                      height="24"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      viewBox="0 0 24 24"
                      width="24"
                    >
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  </div>
                  <span>Get a detailed breakdown of your SEO strengths and weaknesses</span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="rounded-full bg-green-100 dark:bg-green-900 p-1 mt-0.5">
                    <svg
                      className="h-4 w-4 text-green-600 dark:text-green-400"
                      fill="none"
                      height="24"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      viewBox="0 0 24 24"
                      width="24"
                    >
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  </div>
                  <span>Receive personalized recommendations for improvement</span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="rounded-full bg-green-100 dark:bg-green-900 p-1 mt-0.5">
                    <svg
                      className="h-4 w-4 text-green-600 dark:text-green-400"
                      fill="none"
                      height="24"
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      viewBox="0 0 24 24"
                      width="24"
                    >
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  </div>
                  <span>Share your results with custom social media cards</span>
                </li>
              </ul>
              <div>
                <Button asChild size="lg">
                  <Link href="/quizzes">
                    Start Your SEO Assessment
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl blur-xl opacity-20 -z-10"></div>
              <div className="relative bg-white dark:bg-gray-950 rounded-xl border shadow-lg overflow-hidden">
                <div className="p-6">
                  <div className="flex flex-col items-center text-center gap-4">
                    <div className="relative w-32 h-32">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-4xl font-bold">78%</span>
                      </div>
                      <svg className="w-full h-full" viewBox="0 0 100 100">
                        <circle
                          className="text-muted stroke-current"
                          strokeWidth="10"
                          fill="transparent"
                          r="40"
                          cx="50"
                          cy="50"
                        />
                        <circle
                          className="text-blue-500 stroke-current"
                          strokeWidth="10"
                          strokeLinecap="round"
                          fill="transparent"
                          r="40"
                          cx="50"
                          cy="50"
                          strokeDasharray="196"
                          strokeDashoffset="43"
                          transform="rotate(-90 50 50)"
                        />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold">Technical SEO Quiz</h3>
                      <p className="text-sm text-muted-foreground mt-1">Good</p>
                    </div>
                    <div className="grid grid-cols-3 gap-4 w-full">
                      <div className="flex flex-col items-center">
                        <div className="text-sm font-medium">Site Architecture</div>
                        <div className="w-full h-2 bg-muted rounded-full mt-1 overflow-hidden">
                          <div className="bg-blue-500 h-full rounded-full" style={{ width: "85%" }}></div>
                        </div>
                      </div>
                      <div className="flex flex-col items-center">
                        <div className="text-sm font-medium">Page Speed</div>
                        <div className="w-full h-2 bg-muted rounded-full mt-1 overflow-hidden">
                          <div className="bg-blue-500 h-full rounded-full" style={{ width: "65%" }}></div>
                        </div>
                      </div>
                      <div className="flex flex-col items-center">
                        <div className="text-sm font-medium">Mobile</div>
                        <div className="w-full h-2 bg-muted rounded-full mt-1 overflow-hidden">
                          <div className="bg-blue-500 h-full rounded-full" style={{ width: "75%" }}></div>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-2">
                      <Button variant="outline" size="sm">
                        <svg className="h-4 w-4 mr-1" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                        </svg>
                        Share
                      </Button>
                      <Button variant="outline" size="sm">
                        <svg className="h-4 w-4 mr-1" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
                        </svg>
                        Tweet
                      </Button>
                      <Button variant="outline" size="sm">
                        <svg className="h-4 w-4 mr-1" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                        </svg>
                        Share
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}

