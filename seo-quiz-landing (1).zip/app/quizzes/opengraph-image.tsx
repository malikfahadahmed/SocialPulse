import { ImageResponse } from "next/og"

// Route segment config
export const runtime = "edge"

// Image metadata
export const alt = "Social Pulse SEO Quizzes"
export const size = {
  width: 1200,
  height: 630,
}

// Image generation
export default async function Image() {
  return new ImageResponse(
    <div
      style={{
        fontSize: 32,
        background: "linear-gradient(to bottom right, #eff6ff, #dbeafe)",
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: 40,
        position: "relative",
      }}
    >
      <div style={{ position: "absolute", top: 30, left: 30, display: "flex", alignItems: "center", gap: 8 }}>
        <svg
          width="32"
          height="32"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#3b82f6"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M18 3a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3H6a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3V6a3 3 0 0 0-3-3 3 3 0 0 0-3 3 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 3 3 0 0 0-3-3z"></path>
        </svg>
        <span style={{ fontWeight: "bold", color: "#3b82f6" }}>Social Pulse</span>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 24,
          maxWidth: "80%",
        }}
      >
        <div
          style={{
            fontSize: 64,
            fontWeight: "bold",
            textAlign: "center",
            color: "#1e293b",
            lineHeight: 1.2,
          }}
        >
          Choose Your SEO Quiz
        </div>

        <div
          style={{
            fontSize: 32,
            color: "#475569",
            textAlign: "center",
            maxWidth: "90%",
          }}
        >
          Test your knowledge across all aspects of search engine optimization
        </div>

        <div
          style={{
            display: "flex",
            gap: 20,
            marginTop: 20,
          }}
        >
          {["On-Page", "Technical", "Keywords", "Mobile", "Local", "Content"].map((category, i) => (
            <div
              key={i}
              style={{
                padding: "12px 16px",
                borderRadius: 8,
                backgroundColor: "#3b82f6",
                color: "white",
                fontSize: 20,
                fontWeight: "bold",
              }}
            >
              {category}
            </div>
          ))}
        </div>
      </div>

      <div
        style={{
          position: "absolute",
          bottom: 30,
          fontSize: 18,
          color: "#475569",
          display: "flex",
          alignItems: "center",
          gap: 8,
        }}
      >
        <svg
          width="20"
          height="20"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#475569"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
        </svg>
        <span>Powered by Skyreach</span>
      </div>
    </div>,
    { ...size },
  )
}

