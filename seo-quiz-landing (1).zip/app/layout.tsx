import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Social Pulse - SEO Quiz & Analysis Tool",
  description:
    "Master SEO with our comprehensive quiz collection, get expert recommendations, and share your results. Powered by Skyreach.",
  icons: {
    icon: "/favicon.ico",
    apple: "/apple-icon.png",
  },
  // Open Graph metadata for social media sharing
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://socialpulse.app", // Replace with your actual domain
    title: "Social Pulse - SEO Quiz & Analysis Tool",
    description:
      "Master SEO with our comprehensive quiz collection, get expert recommendations, and share your results. Powered by Skyreach.",
    siteName: "Social Pulse",
  },
  // Twitter Card metadata
  twitter: {
    card: "summary_large_image",
    title: "Social Pulse - SEO Quiz & Analysis Tool",
    description:
      "Master SEO with our comprehensive quiz collection, get expert recommendations, and share your results. Powered by Skyreach.",
    creator: "@socialpulse", // Replace with your Twitter handle
  },
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'