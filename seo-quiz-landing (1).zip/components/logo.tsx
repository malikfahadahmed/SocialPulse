import { PowerIcon as Pulse } from "lucide-react"
import Link from "next/link"

export function Logo() {
  return (
    <Link href="/" className="flex items-center gap-2 font-bold">
      <Pulse className="h-5 w-5 text-blue-600 dark:text-blue-400" />
      <span>Social Pulse</span>
    </Link>
  )
}

